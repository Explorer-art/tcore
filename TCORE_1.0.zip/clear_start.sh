while :
do
  echo "Start server"
  luajit start.lua
  sleep 1
done
