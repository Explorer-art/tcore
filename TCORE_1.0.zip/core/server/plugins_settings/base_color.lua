t = {
	base_color = "#F4A900"
}

return t