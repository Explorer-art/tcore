--Chat plugin
local M = {}

local api

local base_color_config = require "core.server.plugins_settings.base_color"
local base_color = base_color_config.base_color

local prefixes_settings_config = require "core.server.plugins_settings.prefixes_settings"
local prefix_admin = prefixes_settings_config.admin
local prefix_moder = prefixes_settings_config.moder
local prefix_junior = prefixes_settings_config.junior
local prefix_default = prefixes_settings_config.default

local chat_message = function(text,type, just_for_host, client)
	local c = "white"
	if type == "error" then
		c = "red"
	elseif type == "system" then
		c = "grey"
	end
	-- print("Chat_message: ", text, type, just_for_host, client)
	api.call_function("chat_function", "<color="..c..">"..text.."</color>", just_for_host, client)
end

local HOST_IS_PLAYER = true

local prefix

local function attribute_message(text,client)
	print("Attribute message is :", text, client)
	local client_data = api.get_data("clients_data")[client]
	local client_uuid = client_data.uuid

	local client_civ = HOST_IS_PLAYER and game_data.player_land or ""
	local client_name = HOST_IS_PLAYER and settings.name or ""
    local custom_id = ""
	if client then
		client_civ = client_data.civilization
		client_name = client_data.name
        -- local cl_data = api.get_data("clients_data")[client]
	end
	
	local i, j = string.find(text, '|')

	if i and j then
		api.call_function("chat_message", "[TCORE] Вы используете запрещённые символы в чате!", "error", true, client)
		return false
	end
	
	if client_data.permissions_group == "admin" then
		prefix = prefix_admin
		client_name = "<color=yellow>"..client_name.."</color>"
	elseif client_data.permissions_group == "moder" then
		prefix = prefix_moder
	elseif client_data.permissions_group == "junior" then
		prefix = prefix_prem
	elseif client_uuid == "5291686919def149031d686b77a93edbabd2fb72afb85ffc6c2f1c0a" then
		prefix = prefix_default
	else
		prefix = prefix_default
	end
	
	local c = game_data.lands[client_civ].color
	local res = prefix.." "..client_name.." <color="..lume.round(c[1]/255, .01)..","..lume.round(c[2]/255, .01)..","..lume.round(c[3]/255, .01)..
	",1>"..game_data.lands[client_civ].name.."</color>: "..text
	return res
end

function M.init(_api)
	api = _api
	
	local prefixes_settings = require "core.server.plugins_settings.prefixes_settings"

	local prefix_admin = prefixes_settings.admin
	local prefix_moder = prefixes_settings.moder
	local prefix_prem = prefixes_settings.prem
	local prefix_default = prefixes_settings.default
	
	api.register_function("chat_message", chat_message)
	api.register_function("attribute_message", attribute_message)
	HOST_IS_PLAYER = api.get_data("HOST_IS_PLAYER")
end

function M.on_player_registered(client)
    local client_data = api.get_data("clients_data")[client]
    
    local client_name = api.get_data("clients_data")[client].name
    
	if api.get_data("clients_data")[client].permissions_group == "admin" then
		prefix = prefix_admin
		client_name = "<color=yellow>"..client_name.."</color>"
	elseif api.get_data("clients_data")[client].permissions_group == "moder" then
		prefix = prefix_moder
	elseif api.get_data("clients_data")[client].permissions_group == "junior" then
		prefix = prefix_prem
	elseif client_uuid = "5291686919def149031d686b77a93edbabd2fb72afb85ffc6c2f1c0a" then
		prefix = prefix_default
	else
		prefix = prefix_default
	end
	
	if client_data then
		api.call_function("chat_message", "<color="..base_color..">**</color> "..prefix.." <color=white>"..client_name..
			"</color><color="..base_color.."> зашёл на сервер</color> <color=white>("..game_data.lands[client_data.civilization].name..") </color>")
	end
end

function M.on_player_disconnected(client)
	api.call_function("chat_message", "<color="..base_color..">**</color> "..api.get_data("clients_data")[client].name.."<color="..base_color.."> вышел с сервера</color>")
end

return M