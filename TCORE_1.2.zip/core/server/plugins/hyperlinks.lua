-- hyperlinks
local M = {}

local timer_module = require "core.timer"

local api

local server_config = require "core.server.plugins_settings.server_config"
local base_color = server_config.base_color

-- List of hyperlinks. Format
-- <unique string>: <link>
local list = {
    discord = "https://discord.gg"
}

-- Messages displayed in chat
local messages = {
    "\n<color="..base_color..">></color><color=white> Первое сообщение</color>\n",
    "\n<color="..base_color..">></color><color=white> Второе сообщение</color>\n",
    "\n<color="..base_color..">></color><color=white> Третие сообщение</color>\n",
    "\n<color="..base_color..">></color><color=white> Четвёртое сообщение</color>\n",
    "\n<color="..base_color..">></color><color=white> Пятое сообщение</color>\n"
}

local function send_message()
    api.call_function("chat_message", lume.randomchoice(messages))
end

function M.init(_api)
	api = _api
end

local is_first = true

function M.on_player_joined(client)
    -- Because this function does not work in init function. Why???
    if is_first then
        timer_module.every(300, send_message)
        is_first = false
    end
	local t = {
        type = "hyperlinks",
        data = {
            list = list
        }
    }
    api.send_data(to_json(t), client)
end

return M