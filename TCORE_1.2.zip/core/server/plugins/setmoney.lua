-- Plugin developer: Truzme_#0751
-- 2x2x

local M = {}

local api

local server_config = require "core.server.plugins_settings.server_config"
local base_color = server_config.base_color

local function setmoney(client, args)
	if not args[2] then
		api.call_function("chat_message", "<color="..base_color..">[TCORE]</color> /setmoney [количество]", "system", true, client)
		return false
	end
	
	local client_data = api.get_data("clients_data")[client]
	local amount = args[2]
	
	game_data.lands[client_data.civilization].money = amount
	
	api.call_function("chat_message", "<color="..base_color..">[TCORE]</color><color=yellow> Успешно выдано!</color>", "system", true, client)
end

function M.init(_api)
	api = _api
	api.register_command("/setmoney", setmoney)
end

return M