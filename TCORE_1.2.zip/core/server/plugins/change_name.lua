local M = {}

local api

local server_config = require "core.server.plugins_settings.server_config"
local base_color = server_config.base_color

local luautf8 = require "lua-utf8"

local function set_civ_name(civ, name)
	if game_data.lands[civ] then
		game_data.lands[civ].name = name
		return true
	end
	return false
end

local function name(client, args)
	local client_data = api.get_data("clients_data")[client]
	local new_name = join(args, " ", 2)
	
	if not args[2] then
		api.call_function("chat_message", "<color="..base_color..">[TCORE]</color> /name [название страны]", "system", true, client)
		return false
	end
	
	if luautf8.len(new_name) > 35 then
	    api.call_function("chat_message", "[TCORE] Название страны не должно быть длиннее 25 символов.", "error", true, client)
		return false
	end

	local c_name = game_data.lands[client_data.civilization].name
	api.call_function("chat_message", "<color="..base_color..">[TCORE]</color><color=white> Цивилизация </color><color=#BA55D3>"..c_name.."</color><color=white> получает название </color><color=#BA55D3>"..new_name.."</color>", "system")
	set_civ_name(client_data.civilization, string.sub(new_name, 1, -2))
end

local function set_name(client, args)
    local name = api.get_data("clients_data")[client]
    
    local client_name = api.call_function("get_client_name", args[2])
    
    local new_name = join(args, " ", 3)
    
    if not args[2] then
		api.call_function("chat_message", "<color="..base_color..">[TCORE]</color> /setname [ник] [название страны]", "system", true, client)
		return false
    end
    
    if luautf8.len(new_name) > 35 then
	    api.call_function("chat_message", "[TCORE] Название страны не должно быть длиннее 25 символов.", "error", true, client)
		return false
	end

	local c_name = game_data.lands[client_data.civilization].name
	api.call_function("chat_message", "<color="..base_color..">[TCORE]</color><color=white> Администратор "..name.." изменил название цвилизации "..c_name.." на "..new_name.."</color>", "system")
	set_civ_name(client_data.civilization, string.sub(new_name, 1, -2))
end

function M.init(_api)
	api = _api
	api.register_command("/name", name)
	api.register_command("/setname", set_name)
end

return M