t = {
	base_color = "#F4A900",
	minimum_step_next_game = 35

}

return t