local t = {
	admin = "<color=#B00000>[Админ]</color>",
	moder = "<color=#00CF00>[Модератор]</color>",
	junior = "<color=#42aaff>[Мл. Модератор]</color>",
	default = "<color=#808080>[Игрок]</color>"
}

return t