t = {
	welcome_message = "\n===========================\n<color=white>Добро пожаловать на сервер!</color>\n\n<color=yellow>Удачи!</color>\n===========================\n"
}

return t