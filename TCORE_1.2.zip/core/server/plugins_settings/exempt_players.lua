t = {
	exempt_players_uuid = {""}
}

return t