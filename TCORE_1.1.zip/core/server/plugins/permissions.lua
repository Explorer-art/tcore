-- Permissions plugin

local M = {}

local api

local flatdb = require 'scripts.utils.flatdb'
local db

local permissions_groups = {
    admin = {
		"/kick",
		"/shutdown",
		"/ban",
		"/banid",
		"/banip",
		"/unban",
		"/mute",
		"/unmute",
		"/players",
		"/m",
		"/sm",
		"/sc",
		"/ng",
		"/slist",
		"/rc",
		"/setcolor",
		"/pass",
		"/help",
		"/rtr",
		"/select",
		"/setciv",
		"/vote",
		"/setdifficulty",
		"/sudo",
		"/forcenext",
        "/role",
        "/history",
		"/name",
		"/setname",
		"/civ",
		"/bc",
		"/clearchat",
		"/p1",
		"/p2",
		"/peace",
		"/war",
		"/pact",
		"/ow",
		"/info",
		"/setmoney",
		"/reciv"
	},
    moder = {
		"/players",
		"/m",
		"/sm",
		"/sc",
		"/ng",
		"/slist",
		"/kick",
		"/ban",
		"/unban",
		"/bc",
		"/setcolor",
		"/pass",
		"/help",
		"/rtr",
		"/select",
		"/vote",
		"/name",
		"/civ"
	},
    junior = {
		"/players",
		"/m",
		"/ng",
		"/sm",
		"/sc",
		"/slist",
		"/kick",
		"/bc",
		"/setcolor",
		"/pass",
		"/help",
		"/rtr",
		"/select",
		"/setciv",
		"/vote",
		"/name",
		"/civ"
	},
	premium = {
		"/players",
		"/m",
		"/rc",
		"/setcolor",
		"/pass",
		"/help",
		"/select",
		"/setciv",
		"/vote",
		"/name",
		"/civ"
	},
	player = {
		"/players",
		"/m",
		"/rc",
		"/setcolor",
		"/pass",
		"/help",
		"/select",
		"/setciv",
		"/vote",
		"/name",
		"/civ"
	}
}

local default_group = "player"

local function set_permissions_group(client, group)
	local clients_data = api.get_data("clients_data")
	clients_data[client].permissions_group = group
end

local function check_command_permission(client, cmd_1)
	if find_in_table(cmd_1, permissions_groups[api.get_data("clients_data")[client].permissions_group]) then
		return true
	else
		return false
	end
end

local function roles(client, args)

end

function M.init(_api)
	api = _api
	api.register_function("set_permissions_group", set_permissions_group)
	api.register_function("check_command_permission", check_command_permission)
    api.register_command("/role", set_role)
end

function M.on_player_registered(client)
	local clients_data = api.get_data("clients_data")
	
	if not clients_data[client].permissions_group then
		set_permissions_group(client, default_group)
	end
end

return M
